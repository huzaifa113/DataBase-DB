#include<iostream>
#include<fstream>
#include<string>
using namespace std;

class student
{
public:
    string C_id;
    string name;
    string gender;
    string cgpa;
    fstream obj;


    student() { }
    void getData(string C_id, string name, string gender, string cgpa)
    {
        obj.open("student.txt", ios::app);
        this->name = name;
        this->gender = gender;
        this->C_id = C_id;
        this->cgpa = cgpa;

        obj << C_id << " " << name << " " << gender << " " << cgpa << endl;
        obj.close();
    }

    void displayData()
    {
        cout << "C_id: " << C_id << endl;
        cout << "Name: " << name << endl;
        cout << "Gender: " << gender << endl;
        cout << "CGPA: " << gender << endl << endl;
    }

    
};

class Faculty
{
public:
    string S_id;
    string name;
    string course;
    string CrHours;
    fstream obj;

    Faculty() { }
    void getData(string S_id, string name, string course, string CrHours)
    {
        obj.open("Faculty.txt", ios::app);
        this->name = name;
        this->course = course;
        this->S_id = S_id;
        this->CrHours = CrHours;

        obj << S_id << " " << name << " " << course << " " << CrHours << endl;
        obj.close();
    }

    void displayData()
    {
        cout << "C_id: " << S_id << endl;
        cout << "Name: " << name << endl;
        cout << "Course: " << course << endl;
        cout << "CrHours: " << CrHours << endl << endl;

    }
};

int main()
{
    student s[8];

    s[0].getData("1000", "Ali", "M", "2.56");
    s[1].getData("1001", "Usman", "M", "3.56");
    s[2].getData("1002", "AliHaider", "M", "4.00");
    s[3].getData("1003", "Ayesha", "M", "0.59");
    s[4].getData("1004", "Amina", "F", "1.89");
    s[5].getData("1005", "Zainab", "F", "2.89");
    s[6].getData("1006", "Aiman", "F", "3.44");
    s[7].getData("1008", "Raza", "M", "1.99");


    Faculty f[10];
    f[0].getData("2000", "Luqman", "ProgrammingFundamentals", "4");
    f[1].getData("2001", "Hamza", "OOP", "4");
    f[2].getData("2002", "Luqman", "DataMining", "3");
    f[3].getData("2003", "Amjad", "MachineLearning", "3");
    f[4].getData("2004", "Luqman", "OperatingSysytem", "4");
    f[5].getData("2005", "Akmal", "CommunicationSkills", "3");
    f[6].getData("2006", "Babar", "LinearAlgebra", "3");
    f[7].getData("2007", "Saima", "Probability", "3");
    f[8].getData("2008", "Romana", "PakistanStudies", "2");
    f[9].getData("2009", "Zuha", "DatabaseSystems", "4");

    return 0;
}