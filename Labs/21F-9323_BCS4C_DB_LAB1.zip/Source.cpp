#include<iostream>
#include<string>
#include<fstream>
using namespace std;

class student
{
	string name;
	string age;
	string contact;
	string blood;
	string degree;
public:
	student(){}

	void namesetter(string name)
	{
		this->name = name;
	}

	void agesetter(string age)
	{
		this->age = age;
	}

	void contactsetter(string contact)
	{
		this->contact = contact;
	}

	void bloodsetter(string blood)
	{
		this->blood = blood;
	}

	void degreesetter(string degree)
	{
		this->degree = degree;
	}
};

int main()
{
	student obj[5];
	fstream obj1;
	string name, blood, degree;
	string age;
	string con;

	obj1.open("data.txt" , ios:: out);
	for (int i = 0; i < 5; i++)
	{
		cout << "Enter Name: ";
		getline(cin, name);
		obj[i].namesetter(name);
		obj1 << name << endl;

		cout << "Enter Age: ";
		getline(cin, age);
		obj[i].agesetter(age);
		obj1 << age << endl;

		cout << "Enter Contact: ";
		getline(cin, con);
		obj[i].contactsetter(con);
		obj1 << con << endl;

		cout << "Enter Blood: ";
		getline(cin, blood);
		obj[i].bloodsetter(blood);
		obj1 << blood << endl;

		cout << "Enter Degree: ";
		getline(cin, degree);
		obj[i].degreesetter(degree);
		obj1 << degree << endl << endl;
	}
	obj1.close();

	system("pause");
	return 0;
}